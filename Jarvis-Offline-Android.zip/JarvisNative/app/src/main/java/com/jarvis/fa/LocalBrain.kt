package com.jarvis.fa

import android.content.Context
import android.icu.text.DateFormat
import android.icu.util.ULocale
import android.net.Uri
import java.util.Date

/** جواب جارویس؛ after بعد از تمام شدن حرف زدن اجرا می‌شود (مثلاً تماس) */
class Reply(val text: String, val sleep: Boolean = false, val after: (() -> Unit)? = null)

/** مغز آفلاین جارویس: دستورهای فارسی را بدون اینترنت و API می‌فهمد */
class LocalBrain(ctx: Context) {
    private val actions = Actions(ctx)
    private val memory = Memory(ctx)
    private val prefs = ctx.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)

    private enum class Kind { CALL, SMS, WHATSAPP }

    private sealed class Pending {
        class Choose(val kind: Kind, val options: List<Pair<String, String>>, val body: String) : Pending()
        class AskBody(val name: String, val number: String) : Pending()
        class ConfirmSms(val name: String, val number: String, val body: String) : Pending()
        class ConfirmSearch(val query: String) : Pending()
    }

    private var pending: Pending? = null

    private fun title() = prefs.getString(Prefs.USER_NAME, "").orEmpty().ifBlank { "قربان" }

    private val stopWords = setOf(
        "زنگ", "بزن", "بزنی", "تماس", "بگیر", "بگیری", "با", "به", "برای", "واسه", "شماره",
        "رو", "را", "یه", "یک", "لطفا", "لطفاً", "برام", "میشه", "می", "شه", "الان", "جارویس",
        "پیام", "پیامک", "مسیج", "بده", "بفرست", "بنویس", "تو", "توی", "از", "واتساپ", "واتس", "اپ"
    )

    private fun cleanName(s: String) = s.split(" ").filter { it.isNotBlank() && it !in stopWords }.joinToString(" ")

    private fun has(t: String, pattern: String) = Regex(pattern).containsMatchIn(t)
    private fun find(t: String, pattern: String) = Regex(pattern).find(t)

    fun think(raw: String): Reply {
        val t = light(raw)
        pending?.let { p ->
            pending = null
            resolvePending(p, t)?.let { return it }
        }
        var m: MatchResult?

        // --- گپ و راهنما ---
        if (has(t, "چه? کار(?:ی|ا|هایی)? (?:می ?تونی|بلدی)|چی بلدی|راهنما")) return Reply(HELP)
        if (has(t, "خداحافظ|شب بخیر|دیگه گوش نده|فعلا بسه|ساکت شو"))
            return Reply("در خدمتم ${title()}، هر وقت خواستید صدام کنید.", sleep = true)
        if (has(t, "جوک|لطیفه|بخندون")) return Reply(JOKES.random())
        if (has(t, "(?:تو )?کی هستی|اسمت چیه|خودتو معرفی کن"))
            return Reply("من جارویسم، دستیار شخصی شما. همه‌چیزم روی همین گوشیه.")
        if (has(t, "مرسی|ممنون|دستت درد نکنه|قربونت|متشکرم"))
            return Reply(listOf("خواهش می‌کنم ${title()}.", "وظیفه‌ست.", "قابلی نداشت.").random())
        if (has(t, "خوبی|چطوری|حالت چطوره|چه خبر"))
            return Reply(listOf("عالی‌ام ${title()}، شما چطورید؟", "همه‌چیز تحت کنترله.").random())
        if (has(t, "^(?:سلام|درود|صبح بخیر|عصر بخیر|هی)(?:\\s|$)") && t.split(" ").size <= 3)
            return Reply("سلام ${title()}، در خدمتم.")

        // --- اسم کاربر ---
        if (has(t, "اسم(?:م| من) چیه|منو می ?شناسی")) {
            val n = prefs.getString(Prefs.USER_NAME, "").orEmpty()
            return Reply(if (n.isNotBlank()) "شما $n هستید." else "هنوز اسمتون رو نگفتید. بگید «اسم من فلانیه».")
        }
        m = find(t, "(?:اسم(?:م| من)|منو صدا کن|صدام کن)\\s+(.+)")
        if (m != null) {
            var n = m.groupValues[1].replace(Regex("\\s+(?:هست|است|هستش)$"), "").trim()
            n = n.replace(Regex("([اوآ])ست$"), "$1").replace(Regex("(.{2,}ی)ه$"), "$1")
            prefs.edit().putString(Prefs.USER_NAME, n).apply()
            return Reply("خوشبختم $n.")
        }

        // --- حافظه ---
        m = find(t, "(?:یادت باشه|یادت بمونه|به خاطر بسپار|یادداشت کن)(?: که)?\\s+(.+)")
        if (m != null) { memory.add(m.groupValues[1]); return Reply("یادم می‌مونه ${title()}.") }
        if (has(t, "چی(?:ا| ها)? یادته|چی(?:زی)? (?:از من )?می ?دونی")) {
            val all = memory.all()
            return Reply(if (all.isEmpty()) "هنوز چیزی بهم نگفتید که یادم بمونه." else "اینا یادمه: " + all.joinToString(". "))
        }
        if (has(t, "همه ?چی(?:و|رو)? (?:فراموش|پاک) کن")) { memory.clear(); return Reply("همه‌چیز پاک شد.") }
        m = find(t, "(?:فراموش کن)(?: که)?\\s+(.+)|(.+?)\\s+(?:رو|را)\\s+فراموش کن")
        if (m != null) {
            val g = m.groupValues
            val q = norm(g[1].ifBlank { g[2] })
            val i = memory.all().indexOfFirst { norm(it).contains(q) || q.contains(norm(it)) }
            return Reply(if (i >= 0 && memory.remove(i)) "فراموشش کردم." else "همچین چیزی یادم نبود.")
        }

        // --- ساعت، تاریخ، باتری ---
        if (has(t, "ساعت چند(?:ه)?|چه ساعتیه|ساعت رو بگو")) {
            val f = android.icu.text.SimpleDateFormat("H:mm", ULocale("fa_IR"))
            return Reply("ساعت الان ${f.format(Date())}.")
        }
        if (has(t, "تاریخ|چندم(?:ه)?(?:\\s|$)|چه روزی(?:ه)?|امروز چه")) {
            val f = DateFormat.getDateInstance(DateFormat.FULL, ULocale("fa_IR@calendar=persian"))
            return Reply("امروز ${f.format(Date())}.")
        }
        if (has(t, "باتری|شارژ")) {
            val (pct, charging) = actions.battery()
            return Reply("باتری $pct درصده" + (if (charging) " و داره شارژ می‌شه." else "."))
        }

        // --- تایمر ---
        if (has(t, "تایمر|زمان ?سنج")) {
            val sec = parseDuration(t) ?: return Reply("چند دقیقه؟")
            actions.setTimer(sec)?.let { return Reply(it) }
            return Reply(if (sec >= 60) "تایمر ${sec / 60} دقیقه‌ای شروع شد." else "تایمر $sec ثانیه‌ای شروع شد.")
        }

        // --- آلارم و یادآوری ---
        if (has(t, "آلارم|الارم|ساعت ?زنگ|بیدارم کن|یادم بنداز|یادآوری کن")) {
            val (h, min) = parseTime(t) ?: return Reply("برای چه ساعتی؟")
            var label = "جارویس"
            find(t, "(?:یادم بنداز|یادآوری کن)(?: که)?\\s+(.+)")?.let {
                label = it.groupValues[1].replace(Regex("\\s*ساعت.*$"), "").ifBlank { label }
            }
            actions.setAlarm(h, min, label)?.let { return Reply(it) }
            return Reply("آلارم ساعت $h:${"%02d".format(min)} تنظیم شد.")
        }

        // --- واتساپ ---
        if (has(t, "واتس ?اپ|واتساپ") && has(t, "پیام|بگو|بنویس|بفرست")) {
            val body = find(t, "\\s(?:که|بگو|بنویس)\\s+(.+)$")?.groupValues?.get(1).orEmpty()
            val namePart = t.replace(Regex("\\s(?:که|بگو|بنویس)\\s+.+$"), "")
            return withContact(Kind.WHATSAPP, namePart, body)
        }

        // --- پیامک ---
        m = find(t, "(?:پیام|پیامک|اس ?ام ?اس|مسیج)\\s*(?:بده|بفرست|بزن|بنویس)")
        if (m != null) {
            val before = t.substring(0, m.range.first)
            val after = t.substring(m.range.last + 1)
            val split = Regex("(?:^|\\s)(?:که|بگو|بنویس|با متن)\\s+").find(after)
            val namePart = if (split != null) after.substring(0, split.range.first) else after
            val body = if (split != null) after.substring(split.range.last + 1) else ""
            return withContact(Kind.SMS, cleanName(before).ifBlank { namePart }, body)
        }
        m = find(t, "(?:پیام|پیامک|مسیج) (?:به|برای) (.+?) (?:بده|بفرست|بزن)(?:\\s+(?:که|بگو))?\\s*(.*)")
        if (m != null) return withContact(Kind.SMS, m.groupValues[1], m.groupValues[2])
        m = find(t, "^به (.+?) بگو(?: که)? (.+)")
        if (m != null) return withContact(Kind.SMS, m.groupValues[1], m.groupValues[2])

        // --- تماس ---
        if (has(t, "زنگ|تماس|شماره بگیر")) return withContact(Kind.CALL, t, "")

        // --- مسیریابی، هوا، یوتیوب، جستجو ---
        m = find(t, "(?:مسیر(?:یابی)?|چطوری برم|چجوری برم|منو ببر)(?: به| تا)?\\s+(.+)")
        if (m != null) return open("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(m.groupValues[1]), "مسیریابی رو باز کردم.")
        m = find(t, "نزدیک ?ترین\\s+(.+)")
        if (m != null) return open("https://www.google.com/maps/search/" + Uri.encode(m.groupValues[1] + " نزدیک من"), "روی نقشه نشونتون دادم.")
        if (has(t, "هوا|آب و هوا")) return open("https://www.google.com/search?q=" + Uri.encode(raw), "وضعیت هوا رو باز کردم.")
        if (has(t, "یوتیوب")) {
            val q = t.replace(Regex("(?:تو|توی|از|در)?\\s*یوتیوب"), " ")
                .replace(Regex("جستجو کن|سرچ کن|پیدا کن|بگرد|پخش کن|بذار|باز کن|برام|رو"), " ").trim()
            return open(
                if (q.isBlank()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=" + Uri.encode(q),
                "یوتیوب رو باز کردم."
            )
        }
        m = find(t, "(?:جستجو|سرچ|گوگل)(?: کن)?\\s+(.+)|(.+?)\\s+(?:رو\\s+)?(?:جستجو|سرچ|گوگل) کن")
        if (m != null) {
            val g = m.groupValues
            val q = g[1].ifBlank { g[2] }
            return open("https://www.google.com/search?q=" + Uri.encode(q), "نتیجه‌ها رو آوردم.")
        }

        // --- باز کردن برنامه ---
        m = find(t, "(.+?)\\s+(?:رو\\s+|را\\s+)?(?:باز کن|اجرا کن|بیار بالا)|(?:برو تو|باز کن)\\s+(.+)")
        if (m != null) {
            val g = m.groupValues
            val name = cleanName(g[1].ifBlank { g[2] })
            val (label, err) = actions.openApp(name)
            if (label == null) return Reply("برنامه‌ای به اسم $name پیدا نکردم.")
            return Reply(err ?: "$label رو باز کردم.")
        }

        // --- جواب از حافظه ---
        val words = norm(t).split(" ").filter { it.length >= 2 && it !in QUESTION_WORDS }
        if (words.isNotEmpty()) {
            val need = maxOf(1, Math.ceil(words.size * 0.6).toInt())
            memory.all().map { f -> f to words.count { norm(f).contains(it) } }
                .filter { it.second >= need }.maxByOrNull { it.second }
                ?.let { return Reply("یادمه: ${it.first}") }
        }

        // --- بلد نیست ---
        pending = Pending.ConfirmSearch(raw)
        return Reply("این یکی رو بلد نیستم ${title()}. تو گوگل بگردم؟")
    }

    private fun open(url: String, ok: String) = Reply(actions.openUrl(url) ?: ok)

    private fun withContact(kind: Kind, nameRaw: String, body: String): Reply {
        val name = cleanName(light(nameRaw))
        val digits = cleanNumber(name)
        val options = if (digits.length >= 5) listOf(digits to digits) else {
            if (name.isBlank()) return Reply("به کی ${title()}؟")
            actions.lookupContacts(name) ?: return Reply("اجازه‌ی دسترسی به مخاطبین داده نشده.")
        }
        if (options.isEmpty()) return Reply("مخاطبی به اسم $name پیدا نکردم ${title()}.")
        if (options.size == 1) return execute(kind, options[0], body)
        pending = Pending.Choose(kind, options, body)
        val names = options.mapIndexed { i, (n, num) ->
            val dup = options.count { it.first == n } > 1
            "${ORDINALS[i]}، $n" + if (dup) " با شماره‌ی آخر ${num.takeLast(4)}" else ""
        }
        return Reply("چند مورد پیدا کردم: ${names.joinToString(". ")}. کدوم؟")
    }

    private fun execute(kind: Kind, target: Pair<String, String>, body: String): Reply {
        val (name, number) = target
        return when (kind) {
            Kind.CALL ->
                if (!actions.canCall()) Reply("مجوز تماس داده نشده.")
                else Reply("چشم، دارم به $name زنگ می‌زنم.", after = { actions.call(number) })
            Kind.SMS -> when {
                !actions.canSms() -> Reply("مجوز پیامک داده نشده.")
                body.isBlank() -> { pending = Pending.AskBody(name, number); Reply("به $name چی بنویسم؟") }
                else -> { pending = Pending.ConfirmSms(name, number, body); Reply("به $name بنویسم: $body. بفرستم؟") }
            }
            Kind.WHATSAPP -> Reply(actions.openWhatsApp(number, body) ?: "واتساپ $name رو باز کردم، فقط ارسال رو بزنید.")
        }
    }

    private fun resolvePending(p: Pending, t: String): Reply? {
        if (has(t, "^(?:نه|نفرست|کنسل|لغو|بیخیال|ولش کن)(?:\\s|$)")) return Reply("باشه، بیخیالش.")
        val yes = has(t, "^(?:آره|اره|بله|آری|بفرست|اوکی|باشه|حتما|حتماً|درسته|بگرد)(?:\\s|$)")
        return when (p) {
            is Pending.ConfirmSms ->
                if (!yes) null
                else if (actions.sendSms(p.number, p.body)) Reply("فرستادم ${title()}.")
                else Reply("پیامک فرستاده نشد.")
            is Pending.AskBody -> { pending = Pending.ConfirmSms(p.name, p.number, t); Reply("به ${p.name} بنویسم: $t. بفرستم؟") }
            is Pending.ConfirmSearch ->
                if (yes) open("https://www.google.com/search?q=" + Uri.encode(p.query), "نتیجه‌ها رو آوردم.") else null
            is Pending.Choose -> {
                val said = cleanName(t)
                val idx = ordinal(t) ?: p.options.indexOfFirst { (n, num) ->
                    said.isNotBlank() && (norm(n).contains(norm(said)) || said.contains(num.takeLast(4)))
                }
                if (idx in p.options.indices) execute(p.kind, p.options[idx], p.body) else null
            }
        }
    }

    private fun ordinal(t: String): Int? = when {
        has(t, "اولی|^اول|^1$|^یک$") -> 0
        has(t, "دومی|^دوم|^2$|^دو$") -> 1
        has(t, "سومی|^سوم|^3$|^سه$") -> 2
        has(t, "چهارمی|^چهارم|^4$") -> 3
        has(t, "پنجمی|^پنجم|^5$") -> 4
        else -> null
    }

    private fun wordsToDigits(s: String): String {
        var r = Regex("(بیست|سی|چهل|پنجاه) و (یک|دو|سه|چهار|پنج|شش|شیش|هفت|هشت|نه)(?=\\s|$)")
            .replace(s) { (NUMWORDS[it.groupValues[1]]!! + NUMWORDS[it.groupValues[2]]!!).toString() }
        r = Regex("(^|\\s)(${NUMWORDS.keys.joinToString("|")})(?=\\s|$)")
            .replace(r) { it.groupValues[1] + NUMWORDS[it.groupValues[2]] }
        return r
    }

    private fun parseTime(t: String): Pair<Int, Int>? {
        val s = wordsToDigits(t)
        var h: Int
        var min = 0
        val m1 = Regex("(\\d{1,2})\\s*[:٫]\\s*(\\d{1,2})").find(s) ?: Regex("(\\d{1,2}) و (\\d{1,2})(?:\\s|$)").find(s)
        when {
            m1 != null -> { h = m1.groupValues[1].toInt(); min = m1.groupValues[2].toInt() }
            Regex("(\\d{1,2}) و نیم").find(s) != null -> { h = Regex("(\\d{1,2}) و نیم").find(s)!!.groupValues[1].toInt(); min = 30 }
            Regex("(\\d{1,2}) و ربع").find(s) != null -> { h = Regex("(\\d{1,2}) و ربع").find(s)!!.groupValues[1].toInt(); min = 15 }
            Regex("ربع به (\\d{1,2})").find(s) != null -> { h = Regex("ربع به (\\d{1,2})").find(s)!!.groupValues[1].toInt() - 1; min = 45 }
            Regex("(\\d{1,2})").find(s) != null -> h = Regex("(\\d{1,2})").find(s)!!.groupValues[1].toInt()
            else -> return null
        }
        if (has(s, "عصر|شب|بعد ?از ?ظهر|بعدازظهر|غروب") && h < 12) h += 12
        else if (has(s, "ظهر") && h < 5) h += 12
        if (h !in 0..23 || min !in 0..59) return null
        return h to min
    }

    private fun parseDuration(t: String): Int? {
        val s = wordsToDigits(t)
        if (has(s, "نیم ساعت")) return 1800
        var total = 0
        Regex("(\\d+) ساعت").find(s)?.let { total += it.groupValues[1].toInt() * 3600 }
        Regex("(\\d+) دقیقه").find(s)?.let { total += it.groupValues[1].toInt() * 60 }
        Regex("(\\d+) ثانیه").find(s)?.let { total += it.groupValues[1].toInt() }
        if (total == 0) Regex("(\\d+)").find(s)?.let { total = it.groupValues[1].toInt() * 60 }
        return total.takeIf { it > 0 }
    }

    companion object {
        private val NUMWORDS = mapOf(
            "یک" to 1, "یه" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5, "شش" to 6, "شیش" to 6,
            "هفت" to 7, "هشت" to 8, "نه" to 9, "ده" to 10, "یازده" to 11, "دوازده" to 12,
            "پانزده" to 15, "پونزده" to 15, "بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50
        )
        private val ORDINALS = listOf("اولی", "دومی", "سومی", "چهارمی", "پنجمی", "ششمی")
        private val QUESTION_WORDS = setOf("چیه", "کیه", "کجاست", "کی", "چنده", "چی", "کجا", "یادته", "بود", "هست", "است", "رو", "را", "که", "از", "به", "در", "با")
        private const val HELP = "می‌تونم مستقیم زنگ بزنم، پیامک بفرستم، واتساپ باز کنم، آلارم و تایمر بذارم، ساعت و تاریخ و باتری رو بگم، برنامه‌ها رو باز کنم، چیزها رو یادم نگه دارم، مسیریابی و جستجو کنم، و گاهی هم جوک بگم."
        private val JOKES = listOf(
            "به ساعت دیواری گفتن چرا همیشه نگرانی؟ گفت آخه وقتم داره تموم می‌شه!",
            "باتری به شارژر گفت بدون تو من هیچی نیستم. شارژر گفت می‌دونم، دو درصد!",
            "من یه دستیار هوشمندم، ولی هنوز نفهمیدم چرا شارژر همیشه یه جای دیگه‌ی خونه‌ست!",
            "از چتر پرسیدن چرا این‌قدر محبوبی؟ گفت چون همیشه زیر بار مشکلات بقیه می‌رم!"
        )
    }
}
