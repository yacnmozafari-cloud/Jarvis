package com.jarvis.fa

import android.content.Context
import org.json.JSONArray
import java.io.File

/** حافظه‌ی بلندمدت جارویس؛ در حافظه‌ی خود گوشی ذخیره می‌شود */
class Memory(ctx: Context) {
    private val file = File(ctx.filesDir, "memory.json")

    @Synchronized fun all(): List<String> = try {
        val a = JSONArray(file.readText())
        List(a.length()) { a.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    @Synchronized fun add(fact: String) = save(all() + fact)

    @Synchronized fun remove(index: Int): Boolean {
        val l = all().toMutableList()
        if (index !in l.indices) return false
        l.removeAt(index)
        save(l)
        return true
    }

    @Synchronized fun clear() = save(emptyList())

    fun asText(): String =
        all().mapIndexed { i, s -> "$i. $s" }.joinToString("\n").ifEmpty { "(هنوز چیزی نیست)" }

    private fun save(l: List<String>) = file.writeText(JSONArray(l).toString())
}
