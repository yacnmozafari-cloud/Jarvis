package com.jarvis.fa

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.media.AudioManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.Executors

/** سرویسی که همیشه روشن می‌ماند، گوش می‌دهد و جواب می‌دهد */
class JarvisService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var busy = false
    private var running = false
    private var lastInteraction = 0L
    private lateinit var brain: LocalBrain
    private var afterSpeak: (() -> Unit)? = null
    private var sleepAfter = false
    private val restart = Runnable { startListening() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        brain = LocalBrain(this)
        setupTts()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            UiLog.add("⚠ تشخیص گفتار روی گوشی در دسترس نیست. برنامه‌ی Google رو نصب یا به‌روز کنید.")
            stopSelf()
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        running = true
        UiLog.add("✅ جارویس روشن شد. بگید «جارویس» و بعد دستورتون رو.")
        startListening()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        worker.shutdownNow()
        UiLog.add("⏹ جارویس خاموش شد.")
        super.onDestroy()
    }

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status != TextToSpeech.SUCCESS) {
                UiLog.add("⚠ موتور صدا راه نیفتاد؛ جواب‌ها فقط نوشته می‌شن.")
                return@TextToSpeech
            }
            val r = tts?.setLanguage(Locale("fa", "IR"))
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) UiLog.add("⚠ صدای فارسی روی گوشی نصب نیست؛ جواب‌ها فقط نوشته می‌شن.")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { handler.post { finishTurn() } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { handler.post { finishTurn() } }
            })
        }
    }

    private fun inCall(): Boolean {
        val mode = getSystemService(AudioManager::class.java).mode
        return mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION || mode == AudioManager.MODE_RINGTONE
    }

    private fun startListening() {
        if (!running || busy) return
        if (inCall()) { restartLater(3000); return }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            restartLater(1500)
        }
    }

    private fun restartLater(ms: Long) {
        handler.removeCallbacks(restart)
        handler.postDelayed(restart, ms)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            onHeard(text)
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    UiLog.add("⚠ مجوز میکروفون داده نشده.")
                    stopSelf()
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                    recognizer?.cancel()
                    restartLater(1500)
                }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> restartLater(3000)
                else -> restartLater(250)
            }
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun onHeard(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) { restartLater(250); return }

        val lower = text.lowercase()
        val wake = WAKE_WORDS.firstOrNull { lower.contains(it) }
        val inConversation = SystemClock.elapsedRealtime() - lastInteraction < FOLLOW_UP_MS
        if (wake == null && !inConversation) { restartLater(250); return }

        val command = if (wake != null) lower.replace(wake, " ").trim(' ', '،', ',', '.') else text
        UiLog.add("🗣 $text")
        if (command.isEmpty()) { respond(Reply("بله قربان؟")); return }

        busy = true
        worker.execute {
            val reply = try { brain.think(command) } catch (e: Exception) { Reply("مشکلی پیش اومد: ${e.message}") }
            handler.post { respond(reply) }
        }
    }

    private fun respond(reply: Reply) {
        busy = true
        afterSpeak = reply.after
        sleepAfter = reply.sleep
        UiLog.add("🤖 ${reply.text}")
        updateNotification(reply.text)
        val ok = ttsReady && tts?.speak(reply.text, TextToSpeech.QUEUE_FLUSH, null, "r${SystemClock.elapsedRealtime()}") == TextToSpeech.SUCCESS
        if (!ok) finishTurn()
    }

    private fun finishTurn() {
        afterSpeak?.let { action ->
            afterSpeak = null
            try { action() } catch (e: Exception) { UiLog.add("⚠ ${e.message}") }
        }
        busy = false
        lastInteraction = if (sleepAfter) 0L else SystemClock.elapsedRealtime()
        sleepAfter = false
        restartLater(if (inCall()) 3000 else 300)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("جارویس فعاله")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }

    private fun startAsForeground() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "جارویس", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotification("بگید «جارویس» و بعد دستورتون رو")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    companion object {
        private const val CHANNEL = "jarvis"
    }
}
