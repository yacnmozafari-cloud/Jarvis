package com.jarvis.fa

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager

/** کارهایی که جارویس مستقیم روی گوشی انجام می‌دهد */
class Actions(private val ctx: Context) {

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun canCall() = has(Manifest.permission.CALL_PHONE)
    fun canSms() = has(Manifest.permission.SEND_SMS)

    /** همه‌ی جفت‌های (اسم، شماره) که به اسم داده‌شده می‌خورند؛ null یعنی مجوز نیست */
    fun lookupContacts(query: String): List<Pair<String, String>>? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val q = norm(query)
        val words = q.split(" ").filter { it.length >= 2 }
        val all = linkedMapOf<String, MutableSet<String>>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                all.getOrPut(n) { linkedSetOf() }.add(cleanNumber(num))
            }
        }
        var hits = all.filterKeys { norm(it) == q }
        if (hits.isEmpty()) hits = all.filterKeys { norm(it).contains(q) }
        if (hits.isEmpty() && words.isNotEmpty()) hits = all.filterKeys { k -> words.all { norm(k).contains(it) } }
        if (hits.isEmpty() && words.isNotEmpty()) hits = all.filterKeys { k -> words.any { norm(k).contains(it) } }
        return hits.entries.take(5).flatMap { (n, nums) -> nums.map { n to it } }.take(6)
    }

    @SuppressLint("MissingPermission")
    fun call(number: String) {
        ctx.getSystemService(TelecomManager::class.java)
            .placeCall(Uri.fromParts("tel", number, null), Bundle())
    }

    @Suppress("DEPRECATION")
    fun sendSms(number: String, message: String): Boolean = try {
        val sms = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                  else SmsManager.getDefault()
        sms.sendMultipartTextMessage(number, null, sms.divideMessage(message), null, null)
        true
    } catch (e: Exception) {
        false
    }

    fun setAlarm(hour: Int, minute: Int, label: String): String? = launch(
        Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )

    fun setTimer(seconds: Int): String? = launch(
        Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "جارویس")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )

    fun openUrl(url: String): String? = launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    fun openWhatsApp(number: String, text: String): String? {
        var d = cleanNumber(number).removePrefix("+")
        if (d.startsWith("00")) d = d.drop(2)
        if (d.startsWith("0")) d = "98" + d.drop(1)
        return openUrl("https://wa.me/$d" + if (text.isNotBlank()) "?text=" + Uri.encode(text) else "")
    }

    /** برنامه را باز می‌کند؛ اسم برنامه‌ی پیدا شده یا null */
    fun openApp(name: String): Pair<String?, String?> {
        val pm = ctx.packageManager
        val q = norm(name)
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val match = apps.firstOrNull { norm(it.first) == q }
            ?: apps.firstOrNull { norm(it.first).contains(q) || (norm(it.first).length >= 3 && q.contains(norm(it.first))) }
            ?: return null to null
        val intent = pm.getLaunchIntentForPackage(match.second) ?: return null to null
        return match.first to launch(intent)
    }

    fun battery(): Pair<Int, Boolean> {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) to bm.isCharging
    }

    /** باز کردن صفحه از پس‌زمینه؛ اگر نشد، دلیلش را برمی‌گرداند */
    private fun launch(i: Intent): String? {
        if (!Settings.canDrawOverlays(ctx))
            return "برای این کار باید تو برنامه اجازه‌ی نمایش روی برنامه‌های دیگر رو بدید."
        return try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (e: Exception) {
            "برنامه‌ای برای این کار روی گوشی پیدا نشد."
        }
    }
}
