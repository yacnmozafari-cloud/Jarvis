package com.jarvis.fa

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** صفحه‌ی تنظیمات: کلید API، مجوزها، روشن و خاموش کردن */
class MainActivity : Activity() {
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 3, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply { text = "جارویس"; textSize = 30f })

        root.addView(TextView(this).apply { text = "بدون اینترنت و API؛ همه‌چیز روی گوشی خودتون."; textSize = 14f })
        val nameInput = EditText(this).apply {
            hint = "اسم شما (اختیاری)"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString(Prefs.USER_NAME, ""))
        }
        root.addView(nameInput)

        root.addView(button("۱. دادن مجوزها") { askPermissions() })
        root.addView(button("۲. اجازه‌ی نمایش روی برنامه‌های دیگر") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("۳. برداشتن محدودیت باتری") { requestBatteryExemption() })
        root.addView(button("▶ روشن کردن جارویس") {
            prefs.edit().putString(Prefs.USER_NAME, nameInput.text.toString().trim()).apply()
            when {
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                    toast("اول مجوز میکروفون رو بدید (دکمه‌ی ۱)")
                else -> {
                    startForegroundService(Intent(this, JarvisService::class.java))
                }
            }
        })
        root.addView(button("⏹ خاموش کردن") { stopService(Intent(this, JarvisService::class.java)) })
        root.addView(button("🧠 پاک کردن حافظه") { Memory(this).clear(); UiLog.add("حافظه پاک شد.") })

        logView = TextView(this).apply { textSize = 14f; setPadding(0, pad, 0, 0) }
        root.addView(
            ScrollView(this).apply { addView(logView) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        UiLog.listener = { runOnUiThread { logView.text = UiLog.text() } }
        logView.text = UiLog.text()
    }

    override fun onPause() {
        UiLog.listener = null
        super.onPause()
    }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("قبلاً انجام شده")
        } else {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
    }
}
