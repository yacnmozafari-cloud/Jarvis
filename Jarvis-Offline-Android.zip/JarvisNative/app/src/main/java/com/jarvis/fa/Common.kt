package com.jarvis.fa

object Prefs {
    const val NAME = "jarvis"
    const val USER_NAME = "user_name"
}

/** کلماتی که جارویس را بیدار می‌کنند */
val WAKE_WORDS = listOf("جارویس", "جاروِیس", "جارویز", "جاروس", "jarvis")

/** بعد از هر جواب، تا این مدت بدون گفتن «جارویس» هم گوش می‌دهد */
const val FOLLOW_UP_MS = 20_000L

fun toLatinDigits(s: String): String = buildString {
    for (c in s) append(
        when (c) {
            in '۰'..'۹' -> '0' + (c - '۰')
            in '٠'..'٩' -> '0' + (c - '٠')
            else -> c
        }
    )
}

fun cleanNumber(s: String): String = toLatinDigits(s).filter { it.isDigit() || it == '+' }

/** یکسان‌سازی سبک برای فهمیدن دستورها */
fun light(s: String): String = toLatinDigits(s).lowercase()
    .replace('ي', 'ی').replace('ك', 'ک').replace("\u200c", " ")
    .replace(Regex("[؟?!،,.]+"), " ")
    .replace(Regex("\\s+"), " ").trim()

/** یکسان‌سازی کامل برای مقایسه‌ی اسم‌ها */
fun norm(s: String): String = light(s)
    .replace('ى', 'ی').replace('ئ', 'ی').replace('ة', 'ه').replace('ؤ', 'و')
    .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')

/** گزارش ساده برای نمایش در صفحه‌ی برنامه */
object UiLog {
    private val lines = ArrayDeque<String>()
    @Volatile var listener: (() -> Unit)? = null

    @Synchronized fun add(s: String) {
        lines.addFirst(s)
        while (lines.size > 60) lines.removeLast()
        listener?.invoke()
    }

    @Synchronized fun text(): String = lines.joinToString("\n\n")
}
